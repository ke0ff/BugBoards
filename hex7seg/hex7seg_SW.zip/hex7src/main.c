/********************************************************************
 ************ COPYRIGHT (c) 2024 by ke0ff, Taylor, TX   *************
 *
 *  File name: main.c
 *
 *  Module:    Control
 *
 *  Summary:   This is the HEX-7seg display bug-board app for the ATTiny
 *
 *******************************************************************/

/********************************************************************
 *  File scope declarations revision history:
 *
 *
 * 05/06/24 jmh:  First test nearly perfect (DP logic was using wrong variable).
 *				  Incorporated DP force-blanking-off mode and debug.
 *				  Segment test: PASS.
 *				  Blanking: Pass
 *				  Added copyright string to pgm mem
 *				  It is DONE, SHIPIT!!!
 *
 * 05/02/24 jmh:  by Joe Haas, KE0FF (creation date)
 *
 *******************************************************************/
/*
 * Created: 05/02/24 15:22
 * Author : joe.haas
 * Executes the ATtiny816 hex 7-segment display.
 *
 * Notes from SCHEM:
 *		HEX/BCD LED Display BugBoard
 *		Implements a HEX to 7-seg decoder with display.
 *		Input is [dcba] with ext pull-downs.
 *		Seg map (CA display, ground port pin to illuminate segment):
 *		      a
 *		     ---
 *		  f /  / b
 *		   ---  <-- g
 *		e /  / c
 *		  ---
 *		   d
 *
 *		$0 = "0", {abcdef}
 *		$1 = "1", {bc}
 *		$2 = "2", {abdeg}
 *		$3 = "3", {abcdg}
 *		$4 = "4", {bcfg}
 *		$5 = "5", {acdfg}
 *		$6 = "6", {acdefg}
 *		$7 = "7", {abc}
 *		$8 = "8", {abcdefg}
 *		$9 = "9", {abcdfg}
 *		$A = 'A', {abcefg}
 *		$B = "b", {cdefg}
 *		$C = "C", {adef}
 *		$D = "d", (bcdeg}
 *		$E = "E", {adefg}
 *		$F = "F", {aefg}
 *
 *		All inputs have pull-downs, so unconnected inputs process as logic "0"
 *		DP is pinned to a test point as are BI & BO.
 *		If (input == $0) & (BI == 1) & (DP == 0):
 *			Display blanks
 *			BO = 1
 *		Else: BO = 0, display = on
 *		
 *		To use blanking, BI of the MSd = 1 & connect BO to
 *		next lowest digit BI, repeat for all but right most digit (leave it's BI open or tie to GND).
 *		If BI is left unconnected, no blanking will occur & BO will remain 0
 *		DP disables blanking and forces BO = 0.  This allows dynamic DP placement with automatic
 *			blanking of digits to the left of the DP digit (the digit with the DP does not blank).
 *
 */

#include <atmel_start.h>
#include "main.h"

/////////////////////////////////////
// file local fn declare
void put_seg(uint8_t inad);
void init_ports(void);
volatile uint8_t copychk(char* buf);

/////////////////////////////////////
// file local variables/const

const uint8_t	seg_lut[] = {
	DIG_0, DIG_8, DIG_4, DIG_C,
	DIG_2, DIG_A, DIG_6, DIG_E,
	DIG_1, DIG_9, DIG_5, DIG_D,
	DIG_3, DIG_B, DIG_7, DIG_F
};
uint8_t	blankstat;

////////////////////////////////////////////////////////////////////////////                                             
//			        ==     ==     =     =======  =     =        
//			        = =   = =    = =       =     ==    =        
//			        =  = =  =   =   =      =     = =   =        
//			        =   =   =  =     =     =     =  =  =        
//			        =       =  =======     =     =   = =        
//			        =       =  =     =     =     =    ==        
//			        =       =  =     =  =======  =     =        
////////////////////////////////////////////////////////////////////////////
// main()
int main(void){
	volatile uint8_t in;
	volatile uint8_t inreg;
	volatile uint8_t inb;
	volatile uint8_t inbreg;

	init_ports();
	inreg = 0xff;
	inbreg = 0xff;
	blankstat = 0;
	if(copychk("BugBd Hexto7seg - (c) Joseph Haas, KE0FF, 2024.  All rights reserved.")) while(1);
	while(1){
		// get input nybble
		in = PORTC_IN & (INA|INB|INC|IND);
		// process if change
		if(in != inreg){
			inreg = in;
			put_seg(in);
		}
		inb = PORTB_IN & (BLANKI|DPIN);
		if(inb != inbreg){
			inbreg = inb;
			if(inb & DPIN){
				PORTA_OUT &= ~SEGP;
				blankstat = 0;
					put_seg(in);
			}else{
				PORTA_OUT |= SEGP;
				if(inb & BLANKI){
					blankstat = 1;
				}else{
					blankstat = 0;
				}
				put_seg(in);
			}
/*			// process blank input & update display
			if(inb & BLANKI){
				blankstat = 1;
				put_seg(in);
			}else{
				blankstat = 0;
				put_seg(in);
			}*/
		}
	}
} // end main()

////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////
// copychk(char* buf) is an attempt to tick the optimizer into storing the
//	copyright string into program memory.  Copyright must start with "Bug"
//	or execution halts.
//
volatile uint8_t copychk(char* buf){

	if(*buf++ != 'B') return 1;
	if(*buf++ != 'u') return 1;
	if(*buf++ != 'g') return 1;
	return 0;
}
	
/////////////////////////////////////
// put_seg(char inad) writes data to segment ports
//	inad == input nybble (bitreversed per segment LUT)
//	blankstat is global blanking input status
//	if input nybble == $0 & BI == 1 display blanks; also, BO = 1
//	else display active & BO = 0
//
void put_seg(uint8_t inad){
	uint8_t	i=inad;
	
	if((i == 0) && blankstat){
		//blank segD and set blank out
		PORTB_OUT |= BLANKO|SEGDB;
		// blank all other segs except DP
		PORTA_OUT |= ~SEGP;
	}else{
		i = seg_lut[inad];
		if(i & SEGD){
			PORTB_OUT &= ~SEGDB;
		}else{
			PORTB_OUT |= SEGDB;
		}
		PORTA_OUT = (PORTA_OUT & SEGP) | (~i & ~SEGP);
		// disable blank out
		PORTB_OUT &= ~BLANKO;
	}
	return;
}

/////////////////////////////////////
// init_ports() initializes GPIO
//
void init_ports(void){

	// init GPIO DDR and IPL port reg
	PORTA_DIR = 0xFE;									// all 1s to blank segments
	PORTA_OUT = 0xFE;
	PORTB_DIR = SEGDB|BLANKO;
	PORTB_OUT = SEGDB;
	PORTC_DIR = 0;
	PORTC_PIN0CTRL &= ~PORT_PULLUPEN_bm;				// disable pullups
	return;
}

// EOF main.c
//

