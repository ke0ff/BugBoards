/********************************************************************
 ************ COPYRIGHT (c) 2024 by ke0ff, Taylor, TX   *************
 *
 *  File name: main.c
 *
 *  Module:    Control
 *
 *  Summary:   This is the bug-board clock app for the ATTiny
 *
 *******************************************************************/

/********************************************************************
 *  File scope declarations revision history:
 *
 *
 * 05/15/24 jmh:  by Joe Haas, KE0FF (creation date) - initial code to toggle 1PPS as fast as possible inside main()
 *
 *******************************************************************/
/*
 * Created: 05/15/24 15:22
 * Author : joe.haas
 * Executes the ATtiny816 clock function.
 *
 * Notes from SCHEM:
 *		Takes input from 3 BCD rotary switches to produce a variable TTL clock output
 *		Optionally, a sine oscillator is possible using the DAC output of the ATtiny-816.
 *		Currently, this project is a shell that still requires SW elements to be included
 *		and debugged.
 *
 */

#include <atmel_start.h>
#include "main.h"

/////////////////////////////////////
// file local fn declare
void init_ports(void);
volatile uint8_t copyfail(char* buf);

/////////////////////////////////////
// file local variables/const

////////////////////////////////////////////////////////////////////////////                                             
//			        ==     ==     =     =======  =     =        
//			        = =   = =    = =       =     ==    =        
//			        =  = =  =   =   =      =     = =   =        
//			        =   =   =  =     =     =     =  =  =        
//			        =       =  =======     =     =   = =        
//			        =       =  =     =     =     =    ==        
//			        =       =  =     =  =======  =     =        
////////////////////////////////////////////////////////////////////////////
// main()
int main(void){

	init_ports();
	if(copyfail("BugBd Clock - (c) Joseph Haas, KE0FF, 2024.  All rights reserved.")) while(1);
	while(1){
			PORTA_OUT ^= PPS1;		// debug toggle
	}
} // end main()

////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////
// copychk(char* buf) is an attempt to tick the optimizer into storing the
//	copyright string into program memory.  Copyright must start with "Bug"
//	or execution halts.
//
volatile uint8_t copyfail(char* buf){

	if(*buf++ != 'B') return 1;
	if(*buf++ != 'u') return 1;
	if(*buf++ != 'g') return 1;
	return 0;
}

/////////////////////////////////////
// init_ports() initializes GPIO
//
void init_ports(void){

	// init GPIO DDR and IPL port reg
	PORTA_DIR = ~ENAB;									// all 1s to blank segments
	PORTA_OUT = GM_N|G1_N|G10_N;
	PORTB_DIR = ~ENABS_N;
	PORTB_OUT = 0;
	PORTC_DIR = 0;
	PORTA_PIN2CTRL &= ~PORT_PULLUPEN_bm;				// disable pullups
	PORTB_PIN4CTRL &= ~PORT_PULLUPEN_bm;
	PORTC_PIN0CTRL &= ~PORT_PULLUPEN_bm;
	PORTC_PIN1CTRL &= ~PORT_PULLUPEN_bm;
	PORTC_PIN2CTRL &= ~PORT_PULLUPEN_bm;
	PORTC_PIN3CTRL &= ~PORT_PULLUPEN_bm;
	return;
}

// EOF main.c
//

