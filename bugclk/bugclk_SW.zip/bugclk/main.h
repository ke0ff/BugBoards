/********************************************************************
 ************ COPYRIGHT (c) 2024 by ke0ff, Taylor, TX   *************
 *
 *  File name: main.h
 *
 *  Module:    Control
 *
 *  Summary:   This is the header file for the banksw/rdu app.
 *
 *******************************************************************/

/********************************************************************
 *  File scope declarations revision history:
 *    02-20-24 jmh:  creation date
 *
 *******************************************************************/
#if defined(__DOXYGEN__)
/** \def wdr()
    \ingroup avr_interrupts

    Kicks watchdog timer

    In order to implement atomic access to multi-byte objects,
    consider using the macros from <util/atomic.h>, rather than
    implementing them manually with wdr().
*/
#define wdr()
#else  /* !DOXYGEN */
# define wdr()  __asm__ __volatile__ ("wdr" ::: "memory")
#endif /* DOXYGEN */


//------------------------------------------------------------------------------
// extern defines
//------------------------------------------------------------------------------
// process_xxx() command defines

#define TIMER_CLEAR	0xffff				// timer clear cmd
#define SYSCLK		3333333				// Hz

// timer value defines -- This timer lashup has an uncertainty of +1,-0 base-units due to the uncertainty of synchronization with the prescaler in the MCU hardware.
//		Thus, for low timer values (values less than, say, 5) add a unit to cover this.
//#define MS5			(380*2)				// 5ms			// cheesy for-loop timing value 378 was measured and verified in the TUNE build using 20MHz master clock and 3.333MHz processor clock //
#define TIC			5						// #ms per ISR "tic"
#define MS5			((5/TIC) + 1)			// 5ms, plus 1 for the ISR alignment uncertainty
#define MS10		(10/TIC)				// 10ms
#define MS15		(15/TIC)				// 15ms
#define MS20		(20/TIC)				// 20ms
#define MS25		(25/TIC)				// 25ms
#define MS35		(35/TIC)				// 35ms
#define MS50		(50/TIC)				// 50ms
#define MS60		(60/TIC)				// 60ms
#define MS75		(75/TIC)				// 75ms
#define MS100		(100/TIC)				// 100ms
#define MS150		(150/TIC)				// 150ms
#define MS175		(175/TIC)				// 175ms
#define MS200		(200/TIC)				// 200ms
#define MS250		(250/TIC)				// 250ms
#define MS300		(300/TIC)				// 300ms
#define MS450		(450/TIC)				// 450ms
#define MS1000		(1000/TIC)				// 1000ms
#define MS2000		(2000/TIC)				// 2000ms
#define MS3000		(3000/TIC)				// 3000ms
#define MS5000		(5000/TIC)				// 5000ms
#define MS10000		(10000/TIC)				// 10000ms

#define RAMP_RATE	1						// brightness rampup rate
#define GPIOWAIT	MS5						// GPIO output settling time
#define DEBOUNCE	MS15					// ADDR input debounce delay
#define RSTWAIT		MS20					// RESET assertion duration
#define CHNGWAIT	MS450					// change-wait: duration after valid input is detected before updating outputs
#define PULSE_DLY	MS75					// pulse1/2 delay
//#define PULSE_TODLY	MS75					// pulse1/2 delay
#define SMUTE_DLY	MS200					// SMUTE pulse-wait delay
#define SMUTE_DBNC	MS75					// SMUTE debounce delay
#define SMUTE_STRETCH_DLY	MS300			// SMUTE pulse-stretch delay
#define BEEP_ON_TIME	MS35

// single-slope PWM/TimerA defines
#define PWM_PERCENT_DFLT	25
#define PWM_FREQ			5000
#define PWM_PER				(SYSCLK / PWM_FREQ)
#define PWM_PCNT_INIT		((PWM_PERCENT_DFLT * PWM_PER) / 100)
#define DIM_PWM				30
#define RAMP_PWM_0			0					// brightness ramp-up profile
#define RAMP_PWM_1			(DIM_PWM/6)
#define RAMP_PWM_2			(DIM_PWM/2)
#define RAMP_PWM_3			(5*DIM_PWM/6)
#define RAMP_PWM_4			(DIM_PWM)
#define BRT_PWM				70

// PORTA
// PA0 = UPDI
#define GM_N		0x02				// PA1	out	mult gate
#define ENAB		0x04				// PA2	in	UCLK enable
#define G1_N		0x08				// PA3	out	1's gate
#define WOA			0x10				// PA4	out	WOA 
#define PPS1		0x20				// PA5	out	1pps 
#define DACO		0x40				// PA6	out	DAC out 
#define G10_N		0x80				// PA7	out	10's gate

// PORTB
//#define 		0x01					// PB0	
//#define 		0x02					// PB1	
//#define 		0x04					// PB2	
//#define 		0x08					// PB3
#define ENABS_N		0x10				// PB4	in	/enab sine
#define PCLK		0x20				// PB5	out	free-run PCLK

// PORTC
#define IND		0x01					// PC0	HEX input nybble
#define INC		0x02					// PC1
#define INB		0x04					// PC2
#define INA		0x08					// PC3	"A" = lsb

// segment maps:

/* bit reversed IN nybble scratchpad
0000	0
0001	8
0010	4
0011	C
0100	2
0101	A
0110	6
0111	E
1000	1
1001	9
1010	5
1011	D
1100	3
1101	B
1110	7
1111	F

*/
////////////////////////////////////////////////////////
// extern Fn defines


// end main.h